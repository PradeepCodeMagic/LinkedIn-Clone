'use client'
import Image from 'next/image'
import profileImg from '../../public/1702740047384.jpg'
import pradeep from '../../public/pradeep.JPEG'
import aws from '../../public/aws.jpg'
import { faArrowRightLong, faBox, faCalendarDays, faCaretDown, faClock, faComment, faEllipsis, faImage, faShare, faThumbsUp } from '@fortawesome/free-solid-svg-icons'
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { useState } from 'react';
import Button from 'react-bootstrap/Button';
import Modal from 'react-bootstrap/Modal';


export default function Home() {
  const [show, setShow] = useState(false);

  const handleClose = () => setShow(false);
  const handleShow = () => setShow(true);
  return (
    <>
      <section>
        <div className="row  mt-3">
          {/* upper-work */}
          <div className="col-lg-12">
            <div className="row bg-white pt-2  align-items-center rounded-3 border">
              {/* img */}
              <div className="col-1 "> <Image src={profileImg} alt='' width={48} className=' rounded-circle ' /></div>
              {/* modal_bar */}
              <div className="col-10 Share-post border" onClick={handleShow}>Share a post </div>

              {/* lover-3 boxess */}
              <div className="row ">
                <div className='col-4  d-flex  justify-content-center align-items-center'>
                  <FontAwesomeIcon icon={faImage} style={{ color: "#378FE9" }} className='myIcon-mid-upper' />
                  <p className='pera'>Media</p>
                </div>
                <div className='col-4  d-flex  justify-content-center align-items-center'>
                  <FontAwesomeIcon icon={faCalendarDays} style={{ color: "#C37D16" }} className='myIcon-mid-upper' />
                  <p className='pera'>Media</p>
                </div>
                <div className='col-4  d-flex  justify-content-center align-items-center'>
                  <FontAwesomeIcon icon={faBox} style={{ color: "#E06847" }} className='myIcon-mid-upper' />
                  <p className='pera'>Media</p>
                </div>
              </div>
            </div>

          </div>

          {/* show-modal */}

          <Modal show={show} onHide={handleClose} >
            <Modal.Header closeButton>
              <div className='d-flex'>
                <div className=''><Image src={profileImg} alt='' width={70} className='img-fluid rounded-circle ' /></div>
                <div className=' ms-3 mt-2'>
                  <h4 className='m-0 p-0'>Pradeep Kumar <FontAwesomeIcon icon={faCaretDown} style={{ width: "9px" }} /></h4>
                  <div className=''> <small>Post to Anyone ?</small> </div>
                </div>
              </div>
            </Modal.Header>
            <Modal.Body>
              <textarea placeholder='What you want to talk about?' className='w-100 textarea'></textarea>
              <div className='d-flex'>
                <div className=''><FontAwesomeIcon icon={faImage} style={{ color: "#666666" }} className='myIcon-mid-upper' /></div>
                <div className='ms-4'><FontAwesomeIcon icon={faCalendarDays} style={{ color: "#666666" }} className='myIcon-mid-upper' /></div>
                <div className='ms-4'><FontAwesomeIcon icon={faBox} style={{ color: "#666666" }} className='myIcon-mid-upper' /></div>
                <div className='ms-4'><FontAwesomeIcon icon={faEllipsis} style={{ color: "#666666" }} className='myIcon-mid-upper' /></div>
              </div>
            </Modal.Body>
            <Modal.Footer>
              <FontAwesomeIcon icon={faClock}  onClick={handleClose} className='myIcon-mid-upper' />
              <Button onClick={handleClose} className='rounded-pill py-1 px-3'>
                Post
              </Button>
            </Modal.Footer>
          </Modal>
          
          {/* { close-modal} */}


          <div className='d-flex justify-content-between align-items-center'>
            <div className='hr'> </div>
            <div className=''>
              <p className='shortBy'>stort by:Top <FontAwesomeIcon icon={faCaretDown} style={{ width: "9px" }} /></p>
            </div>

          </div>

          {/* map this */}
          <div className=' row bg-white p-0 m-1 align-items-center rounded-3 border '>
            <div className='col-12 p-0  '>
              <div className='row px-3 pt-3 m-0  '>
                <div className='col-1 p-0'><Image src={aws} alt='' width={48} /> </div>
                <div className='col-10 profileInfo m-lg-0 ms-sm-0 '>
                  <b>AWS Training & Certification</b>
                  <p>
                    991,135 followers<br /> Promoted
                  </p>
                </div>
                <div className='col-1'><FontAwesomeIcon icon={faEllipsis} className='myIcon-mid-upper' /></div>
              </div>
              {/*pera  */}
              <div className='col-11 profileInfo-pera '>
                The past few months of reflection, recharge, and exploration have not only reenergized me but also provided fresh insights.
              </div>
              {/* img */}
              <div className='col-12 mt-2 p-0'>
                <img src='https://media.licdn.com/dms/image/sync/D4E10AQFOJqAdA9rYcQ/image-shrink_800/0/1703021216649?e=1705737600&v=beta&t=2aaGbUmz1ZTUzFwGfsDuwTqk8kVeFteWtXByTaEtmrA' className='img-fluid ' />
              </div>
              {/* like,share.... */}

              <div className="row p-1 hoverBox m-0 ">
                <div className='col-3 py-0  d-flex  justify-content-center align-items-center'>
                  <FontAwesomeIcon icon={faThumbsUp} style={{ color: "#378FE9" }} className='myIcon-mid-upper' />
                  <p className='pera'>Like</p>
                </div>
                <div className='col-3  d-flex  justify-content-center align-items-center'>
                  <FontAwesomeIcon icon={faComment} style={{ color: "#C37D16" }} className='myIcon-mid-upper' />
                  <p className='pera'>Comment</p>
                </div>
                <div className='col-3  d-flex  justify-content-center align-items-center' >
                  <FontAwesomeIcon icon={faArrowRightLong} style={{ color: "#E06847" }} className='myIcon-mid-upper' />
                  <p className='pera'>Repost</p>
                </div>
                <div className='col-3  d-flex  justify-content-center align-items-center'>
                  <FontAwesomeIcon icon={faShare} style={{ color: "#5E5E5E" }} className='myIcon-mid-upper' />
                  <p className='pera'>Send</p>
                </div>
              </div>

            </div>
          </div>

          {/* 2 */}
          <div className=' row bg-white p-0 m-1 align-items-center rounded-3 border '>
            <div className='col-12 p-0  '>
              <div className='row px-3 pt-3 m-0  '>
                <div className='col-1 p-0'><img src="https://media.licdn.com/dms/image/C4E03AQGDFs4aUhpGww/profile-displayphoto-shrink_100_100/0/1620013737833?e=1710374400&v=beta&t=eNPoINOVgJLfmb5fMNLFzp7b6KnTTaSpVU9_CHOU3yE" alt='' width={48} /> </div>
                <div className='col-10 profileInfo m-lg-0 ms-sm-0 '>
                  <b>Gaurav Daiya</b>
                  <p>
                    991 followers<br /> Promoted
                  </p>
                </div>
                <div className='col-1'><FontAwesomeIcon icon={faEllipsis} className='myIcon-mid-upper' /></div>
              </div>
              {/*pera  */}
              <div className='col-11 profileInfo-pera '>
                The past few months of reflection, recharge, and exploration have not only reenergized me but also provided fresh insights.
              </div>
              {/* img */}
              <div className='col-12 mt-2 p-0'>
                <img src='https://media.licdn.com/dms/image/D5622AQF5o0e2_Z0ozQ/feedshare-shrink_1280/0/1704209222966?e=1707955200&v=beta&t=Tjw5u_XW7pUq-iEAEFb_eZID2xGgXx5vCyPfbGlxFFU' className='img-fluid ' />
              </div>
              {/* like,share.... */}

              <div className="row p-1 hoverBox m-0 ">
                <div className='col-3 py-0  d-flex  justify-content-center align-items-center'>
                  <FontAwesomeIcon icon={faThumbsUp} style={{ color: "#378FE9" }} className='myIcon-mid-upper' />
                  <p className='pera'>Like</p>
                </div>
                <div className='col-3  d-flex  justify-content-center align-items-center'>
                  <FontAwesomeIcon icon={faComment} style={{ color: "#C37D16" }} className='myIcon-mid-upper' />
                  <p className='pera'>Comment</p>
                </div>
                <div className='col-3  d-flex  justify-content-center align-items-center' >
                  <FontAwesomeIcon icon={faArrowRightLong} style={{ color: "#E06847" }} className='myIcon-mid-upper' />
                  <p className='pera'>Repost</p>
                </div>
                <div className='col-3  d-flex  justify-content-center align-items-center'>
                  <FontAwesomeIcon icon={faShare} style={{ color: "#5E5E5E" }} className='myIcon-mid-upper' />
                  <p className='pera'>Send</p>
                </div>
              </div>

            </div>
          </div>
          {/* 3*/}
          <div className=' row bg-white p-0 m-1 align-items-center rounded-3 border '>
            <div className='col-12 p-0  '>
              <div className='row px-3 pt-3 m-0  '>
                <div className='col-1 p-0'><img src="https://media.licdn.com/dms/image/D4D03AQFDyhOQytl_hw/profile-displayphoto-shrink_400_400/0/1702740047384?e=1710374400&v=beta&t=jvzOzaQlTfX-SIxaEolPtP12AuufUziEfD1Y9Bl312I" alt='' width={48} /> </div>
                <div className='col-10 profileInfo m-0 '>
                  <b>Pradeep</b>
                  <p>
                    999 followers<br /> Promoted
                  </p>
                </div>
                <div className='col-1'><FontAwesomeIcon icon={faEllipsis} className='myIcon-mid-upper' /></div>
              </div>
              {/*pera  */}
              <div className='col-11 profileInfo-pera '>
                The past few months of reflection, recharge, and exploration have not only reenergized me but also provided fresh insights.
              </div>
              {/* img */}
              <div className='col-12 mt-2 p-0'>
                <Image src={pradeep} className='img-fluid ' />
              </div>
              {/* like,share.... */}

              <div className="row p-1 hoverBox m-0 ">
                <div className='col-3 py-0  d-flex  justify-content-center align-items-center'>
                  <FontAwesomeIcon icon={faThumbsUp} style={{ color: "#378FE9" }} className='myIcon-mid-upper' />
                  <p className='pera'>Like</p>
                </div>
                <div className='col-3  d-flex  justify-content-center align-items-center'>
                  <FontAwesomeIcon icon={faComment} style={{ color: "#C37D16" }} className='myIcon-mid-upper' />
                  <p className='pera'>Comment</p>
                </div>
                <div className='col-3  d-flex  justify-content-center align-items-center' >
                  <FontAwesomeIcon icon={faArrowRightLong} style={{ color: "#E06847" }} className='myIcon-mid-upper' />
                  <p className='pera'>Repost</p>
                </div>
                <div className='col-3  d-flex  justify-content-center align-items-center'>
                  <FontAwesomeIcon icon={faShare} style={{ color: "#5E5E5E" }} className='myIcon-mid-upper' />
                  <p className='pera'>Send</p>
                </div>
              </div>

            </div>
          </div>
          {/*  4*/}
          <div className=' row bg-white p-0 m-1 align-items-center rounded-3 border '>
            <div className='col-12 p-0  '>
              <div className='row px-3 pt-3 m-0  '>
                <div className='col-1 p-0'><img src="https://media.licdn.com/dms/image/D4D0BAQEvXWthcePYGw/company-logo_200_200/0/1694515726752/wscubetechindia_logo?e=1713398400&v=beta&t=E3r7w_KIXTQrxZoq0lauzrJf5qGwzQiO_9yU4Q8WqAM" alt='' width={48} />  </div>
                <div className='col-10 profileInfo m-0 '>
                  <b>WsCube Tech</b>
                  <p>
                    Upskilling Bharat
                  </p>
                </div>
                <div className='col-1'><FontAwesomeIcon icon={faEllipsis} className='myIcon-mid-upper' /></div>
              </div>
              {/*pera  */}
              <div className='col-11 profileInfo-pera '>
                The past few months of reflection, recharge, and exploration have not only reenergized me but also provided fresh insights.
              </div>
              {/* img */}
              <div className='col-12 mt-2 p-0'>
                <img src='https://media.licdn.com/dms/image/D4D22AQHdk27zNy9hzw/feedshare-shrink_800/0/1702988383951?e=1707955200&v=beta&t=SJl-tcNs_o_scOoNaKi59e45qKnU7KjLYg35uHc3G6M' className='img-fluid ' />
              </div>
              {/* like,share.... */}

              <div className="row p-1 hoverBox m-0 ">
                <div className='col-3 py-0  d-flex  justify-content-center align-items-center'>
                  <FontAwesomeIcon icon={faThumbsUp} style={{ color: "#378FE9" }} className='myIcon-mid-upper' />
                  <p className='pera'>Like</p>
                </div>
                <div className='col-3  d-flex  justify-content-center align-items-center'>
                  <FontAwesomeIcon icon={faComment} style={{ color: "#C37D16" }} className='myIcon-mid-upper' />
                  <p className='pera'>Comment</p>
                </div>
                <div className='col-3  d-flex  justify-content-center align-items-center' >
                  <FontAwesomeIcon icon={faArrowRightLong} style={{ color: "#E06847" }} className='myIcon-mid-upper' />
                  <p className='pera'>Repost</p>
                </div>
                <div className='col-3  d-flex  justify-content-center align-items-center'>
                  <FontAwesomeIcon icon={faShare} style={{ color: "#5E5E5E" }} className='myIcon-mid-upper' />
                  <p className='pera'>Send</p>
                </div>
              </div>

            </div>
          </div>
          {/* 5*/}


        </div>
      </section>
    </>
  )
}
