'use client'
import { faAngleUp, faChevronDown, faEllipsis, faInfo } from '@fortawesome/free-solid-svg-icons'
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import Image from 'next/image'
import profileImg from '../../../public/1702740047384.jpg'

import '../Allcss/Right.css'
import { useState } from 'react';



export default function Right() {
  const [showMore, setShowMore] = useState(false);

  const handleToggle = () => {
    setShowMore(!showMore);
  };
  
  return (
   <section>
    <div className="row border p-3 m-0 mt-3 bg-white rounded-3 border">
      <div className="col-12  d-flex align-items-center justify-content-between p-0 ">
        <div className=""> <h6>LinkedIn News</h6> </div>
        <div className=""><FontAwesomeIcon icon={faInfo} style={{width:"6px",paddingBottom:"9px"}}  /></div>
      </div>

      <div className="col-12 p-0 ">
      <div id="profile-description">
      <div className={`text ${showMore ? '' : 'show-more-height'}`}>
      <ul className= "ps-0">
          <li>
          Google lays off hundreds of workers
            <p>7h ago • 64,764 readers</p>
          </li>
          <li>
          Google lays off hundreds of workers
            <p>7h ago • 64,764 readers</p>
          </li>
          <li>
          Google lays off hundreds of workers
            <p>7h ago • 64,764 readers</p>
          </li>
          <li>
          Google lays off hundreds of workers
            <p>7h ago • 64,764 readers</p>
          </li>
          <li>
          Google lays off hundreds of workers
            <p>7h ago • 64,764 readers</p>
          </li>
          <li>
          Google lays off hundreds of workers
            <p>7h ago • 64,764 readers</p>
          </li>
          
          
        </ul>
      </div>
      <div className="show-more" onClick={handleToggle}>
        {showMore ? <p>Show Less &nbsp;<FontAwesomeIcon icon={faAngleUp} className='myIcon' /></p> : <p>Show More <FontAwesomeIcon icon={faChevronDown} className='myIcon'/></p> }
      </div>
    </div>
        
      </div>
      
    </div>
    {/* add */}
    <div className="row border px-3 m-0 mt-3 bg-white rounded-3 border ">
      <div className="col-12 p-0 m-0 text-end ">
        <small>Ad</small> <FontAwesomeIcon icon={faEllipsis} className='myIcon' />
      </div>
      <div className="col-12 p-0 "> <h2>Stay updated on DX, AI more with Hitachi.</h2> </div>
      <div className="col-12 d-flex align-items-center justify-content-center">
        <div className="mx-2"><Image src={profileImg} alt='' width={74} className='img-fluid rounded-circle ' /></div>
        <div className="mx-2">
          <img src="https://media.licdn.com/dms/image/D5610AQGx37vA-spT9A/image-pad_100_100/0/1694586919856?e=1705489200&v=beta&t=qECj8psV3xRt3fCcNLtJar_SQb3jX8-3RbDDmTv2zks" alt="" width={70} className='img-fluid'/>
        </div>
      </div>
      <div className="col-12 text-center p-0 my-2 Addpera">
        Hitachi Social Innovation is POWERING GOOD
      </div>
      <div className="col-12 text-center mb-4">
        <button>Follow</button>
      </div>
    </div>
   </section>
  )
}
