import React from 'react'
import "../Allcss/Header.css"
import Logo from '../../../public/favicon.ico'
import HeaderProfile from '../../../public/1702740047384.jpg'
import  Image  from 'next/image'
import { faBell, faBriefcase, faBuilding, faCaretDown, faHouseChimney, faMagnifyingGlass, faMessage, faPersonPregnant, faTableCells, faUser } from '@fortawesome/free-solid-svg-icons'
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { Container } from 'react-bootstrap'

export default function Header() {
  return (
    <>
    <section className='Header'>
        <div className='container'>
          <div className="row py-2">

            <div className="col-4  d-flex align-items-center">
            <div className="Logo"> <Image src={Logo} alt='' /> </div>
              <div className="SreachBar d-flex align-items-center">
                <FontAwesomeIcon icon={faMagnifyingGlass} className="fontIcon" /> 
                <input type="text" placeholder='Search' className='SreachBarIncreaseInput'/>
              </div>
            </div>
            
            <div className="col-8  d-flex p-0 m-0 Right align-items-center">
              <div className="col text-center  align-items-center ">
                <FontAwesomeIcon icon={faHouseChimney} className="fontIcon " />
                <p className='m-0 p-0'>Home</p>
              </div>
              <div className="col text-center">
              <FontAwesomeIcon icon={faPersonPregnant} className="fontIcon" />
                <p className='m-0 p-0'>My Network</p>
              </div>
              <div className="col text-center">
              <FontAwesomeIcon icon={faBriefcase} className="fontIcon"  />
                <p className='m-0 p-0'>Jobs</p>
              </div>
              <div className="col text-center">
              <FontAwesomeIcon icon={faMessage} className="fontIcon" />
                <p className='m-0 p-0'>Messaging</p>
              </div>
              <div className="col text-center">
              <FontAwesomeIcon icon={faBell} className="fontIcon" />
                <p className='m-0 p-0'>Notifications</p>
              </div>

              <div className="col text-center border-end hide">
                <Image src={HeaderProfile} className='HeaderProfile img-fluid'/>
                <p className='m-0 p-0'>User <FontAwesomeIcon icon={faCaretDown}  className='DownErro'/></p>
              </div>

              <div className="col text-center hide">
                <FontAwesomeIcon icon={faTableCells} className="fontIcon"/>
                <p className='m-0 p-0'>Business <FontAwesomeIcon icon={faCaretDown}  className='DownErro'/></p>
              </div>

              <div className="col text-center hide">
              <u>Try Premium for ₹0</u>
              </div>

            </div>
          </div>
        </div>
    </section>
    </>
  )
}
