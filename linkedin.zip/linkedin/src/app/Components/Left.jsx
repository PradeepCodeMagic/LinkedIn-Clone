import React from 'react'
import "../Allcss/Left.css"
import Image from 'next/image'
import backImg from '../../../public/Artificial-Intelligence-5.jpg'
import profileImg from '../../../public/1702740047384.jpg'
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { faBookmark, faHashtag, faMoneyBill } from '@fortawesome/free-solid-svg-icons'
export default function Left() {
  return (
    <section>
      <div className=" row p-lg-3 pb-lg-1 p-sm-0 ">

        <div className="col-lg-12 p-0 m-0  upperPart_left rounded">

          <div className="backImg "> <Image src={backImg} alt='' /> </div>
          <div className="profileImg text-center "> <Image src={profileImg} alt='' width={74} className='img-fluid rounded-circle ' /></div>
          <div className="text-center py-3 Name"><b>Pradeep Kumar</b></div>
          <p className="subName">Trainer in WsCube Tech</p>
          {/* hr line */}
          <div className="border-top border-bottom py-2 ">
            <div className="Info-box d-flex justify-content-between align-items-center">
              <div className="py-1 px-2">Profile Viewers</div>
              <div className="py-1 px-2"><span>45</span></div>
            </div>
            <div className="Info-box d-flex justify-content-between align-items-center">
              <div className="py-1 px-2">Post impressions</div>
              <div className="py-1 px-2"><span>18</span></div>
            </div>
          </div>
          {/* hr line */}
          <div className="border-top border-bottom ">
            <div className="Info-box px-3 py-2">
              <small>Strengthen your profile with an AI writing assistant</small>
              <h6 className='pb-2 m-0'><FontAwesomeIcon icon={faMoneyBill} style={{ color: "#FFD43B", width: "16px" }} /> &nbsp; Try Premium for ₹0 </h6>
            </div>
          </div>
            {/* hr line */}
            <div className="border-top ">
            <p className='Down px-3 mb-0'><FontAwesomeIcon icon={faBookmark} style={{ color: "#5E5E5E", width: "12px" }}/>&nbsp; <small>My Items</small> </p>
            </div>

        </div>


        

      </div>

    {/* 2 */}
    <div className=" row p-lg-3 mt-sm-1 d-none d-lg-block">

        <div className="col-lg-12 p-2 m-0  upperPart_left rounded">
          <div className="col-12 Down-font-1 py-2">Recent</div>
          <div className="col-12 "> <FontAwesomeIcon icon={faHashtag} className='myfont'/> <span className='Down-font-1'>&nbsp;india</span></div>
          <div className="col-12 Down-font-2 mt-3">Groups</div>
          <div className="col-12 Down-font-2">Events</div>
          <div className="col-12 Down-font-2">Follwers Hashtags</div>
          <div className="col-12 "> <FontAwesomeIcon icon={faHashtag} className='myfont' /> <span className='Down-font-1'>&nbsp;india</span></div>
          <div className="col-12 Down-font-1 mt-1 mb-3">&nbsp; &nbsp; &nbsp; Sell all</div>
          <div className="cpl-12 text-center border-top py-2">Discover More</div>
        </div>

      </div>
    </section>
  )
}


